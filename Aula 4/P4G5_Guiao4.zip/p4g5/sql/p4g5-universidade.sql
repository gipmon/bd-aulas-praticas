use p4g5 --ligar a base de dados
CREATE SCHEMA aula4_universidade;
CREATE TABLE aula4_universidade.Pessoa (
	nome VARCHAR(50) NOT NULL,
	nmec int PRIMARY KEY,
	data_nasc DATE NOT NULL
);

CREATE TABLE aula4_universidade.Professor (
	nmec int PRIMARY KEY,
	area_cientifica VARCHAR(180) NOT NULL,
	cat_profissional VARCHAR(180) NOT NULL,
	nome_dep VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE aula4_universidade.Estudante_Graduado (
	nmec int PRIMARY KEY,
	grau int NOT NULL,
	nmec_advisor int UNIQUE NOT NULL,
	nome_dep VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE aula4_universidade.Departamento (
	nome VARCHAR(100) PRIMARY KEY,
	localizacao VARCHAR(100) NOT NULL,
	nmec_prof int UNIQUE NOT NULL
);

CREATE TABLE aula4_universidade.Projecto (
	id int PRIMARY KEY,
	orcamento money NOT NULL,
	ent_fin VARCHAR(100) NOT NULL,
	nome VARCHAR(100) NOT NULL,
	data_ini DATE NOT NULL,
	data_fim DATE NOT NULL
);

CREATE TABLE aula4_universidade.Participa (
	id_proj int,
	nmec_prof int,
	PRIMARY KEY(id_proj, nmec_prof)
);

CREATE TABLE aula4_universidade.Trabalha (
	id_proj int,
	nmec_est int,
	PRIMARY KEY(id_proj, nmec_est)
);

CREATE TABLE aula4_universidade.Supervisiona (
	nmec_prof int,
	nmec_est int,
	PRIMARY KEY(nmec_prof, nmec_est) 
);


ALTER TABLE aula4_universidade.Professor ADD CONSTRAINT PROPESFK FOREIGN KEY (nmec) REFERENCES aula4_universidade.Pessoa(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Estudante_Graduado ADD CONSTRAINT ESTPESFK FOREIGN KEY (nmec) REFERENCES aula4_universidade.Pessoa(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Participa ADD CONSTRAINT PARPROFK FOREIGN KEY (nmec_prof) REFERENCES aula4_universidade.Professor(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Departamento ADD CONSTRAINT DEPPROFK FOREIGN KEY (nmec_prof) REFERENCES aula4_universidade.Professor(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Supervisiona ADD CONSTRAINT SUPPROFK FOREIGN KEY (nmec_prof) REFERENCES aula4_universidade.Professor(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Supervisiona ADD CONSTRAINT SUPESTFK FOREIGN KEY (nmec_est) REFERENCES aula4_universidade.Estudante_Graduado(nmec) ON UPDATE NO ACTION;
ALTER TABLE aula4_universidade.Estudante_Graduado ADD CONSTRAINT ESTESTFK FOREIGN KEY (nmec_advisor) REFERENCES aula4_universidade.Estudante_Graduado(nmec) ON UPDATE NO ACTION;
ALTER TABLE aula4_universidade.Trabalha ADD CONSTRAINT TRAESTFK FOREIGN KEY (nmec_est) REFERENCES aula4_universidade.Estudante_Graduado(nmec) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Estudante_Graduado ADD CONSTRAINT ESTDEPFK FOREIGN KEY (nome_dep) REFERENCES aula4_universidade.Departamento(nome) ON UPDATE NO ACTION;
ALTER TABLE aula4_universidade.Professor ADD CONSTRAINT PRODEPFK FOREIGN KEY (nome_dep) REFERENCES aula4_universidade.Departamento(nome) ON UPDATE NO ACTION;
ALTER TABLE aula4_universidade.Participa ADD CONSTRAINT PARTPROFK FOREIGN KEY (id_proj) REFERENCES aula4_universidade.Projecto(id) ON UPDATE CASCADE;
ALTER TABLE aula4_universidade.Trabalha ADD CONSTRAINT TRAPROFK FOREIGN KEY (id_proj) REFERENCES aula4_universidade.Projecto(id) ON UPDATE CASCADE;
