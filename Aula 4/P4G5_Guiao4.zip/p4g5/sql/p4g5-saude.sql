o treuse p4g5 --ligar a base de dados
CREATE SCHEMA aula4_saude;
CREATE TABLE aula4_saude.Farmacia (
	nome VARCHAR(50) PRIMARY KEY,
	endereco VARCHAR(50) NOT NULL,
	telefone int NOT NULL
);

CREATE TABLE aula4_saude.Prescricao (
	n_unico_prescricao int PRIMARY KEY,
	data date NOT NULL,
	nome_farmacia VARCHAR(50) NOT NULL,
	n_sns int NOT NULL,
	n_utente int NOT NULL
);
-- PRESCRICAO
ALTER TABLE aula4_saude.Prescricao ADD CONSTRAINT NFPFN FOREIGN KEY (nome_farmacia) REFERENCES aula4_saude.Farmacia(nome) ON UPDATE CASCADE;
ALTER TABLE aula4_saude.Prescricao ADD CONSTRAINT NSNSPMNSNS FOREIGN KEY (n_sns) REFERENCES aula4_saude.Medico(n_sns) ON UPDATE NO ACTION;
ALTER TABLE aula4_saude.Prescricao ADD CONSTRAINT NUPPNU FOREIGN KEY (n_utente) REFERENCES aula4_saude.Paciente(n_utente) ON UPDATE NO ACTION;

CREATE TABLE aula4_saude.Medico (
	n_sns int PRIMARY KEY,
	nome VARCHAR(40) NOT NULL,
	especialidade VARCHAR(40)
);

CREATE TABLE aula4_saude.Paciente (
	n_utente int PRIMARY KEY,
	nome VARCHAR(40) NOT NULL,
	data_nascimento date NOT NULL,
	endereco VARCHAR(50) NOT NULL
);

CREATE TABLE aula4_saude.CompanhiaFarmaceutica (
	n_registo_nacional int PRIMARY KEY,
	nome VARCHAR(40) NOT NULL,
	endereco VARCHAR(40)
);

CREATE TABLE aula4_saude.Farmaco (
	nome VARCHAR(40) NOT NULL,
	formula VARCHAR(100),
	n_registo_nacional int NOT NULL,
	PRIMARY KEY (nome, n_registo_nacional)
);
-- Farmaco
ALTER TABLE aula4_saude.Farmaco ADD CONSTRAINT NRNFCFNRN FOREIGN KEY (n_registo_nacional) REFERENCES aula4_saude.CompanhiaFarmaceutica(n_registo_nacional) ON UPDATE CASCADE;

CREATE TABLE aula4_saude.Contem (
	n_unico_prescricao int NOT NULL,
	nome VARCHAR(40) NOT NULL,
	n_registo_nacional int NOT NULL,
	PRIMARY KEY (n_unico_prescricao, nome, n_registo_nacional)
);
-- Contem
ALTER TABLE aula4_saude.Contem ADD CONSTRAINT CNCNRN FOREIGN KEY (nome, n_registo_nacional) REFERENCES aula4_saude.Farmaco(nome, n_registo_nacional) ON UPDATE CASCADE;
ALTER TABLE aula4_saude.Contem ADD CONSTRAINT CNUDPPNUP FOREIGN KEY (n_unico_prescricao) REFERENCES aula4_saude.Prescricao(n_unico_prescricao) ON UPDATE NO ACTION;
