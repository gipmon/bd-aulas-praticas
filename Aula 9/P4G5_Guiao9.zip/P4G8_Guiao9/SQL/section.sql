use p4g5;

INSERT INTO football.section(id_section, type) VALUES (1, 'Topo Norte');
INSERT INTO football.section(id_section, type) VALUES (2, 'Central');