use p4g5;

INSERT INTO football.court(id_court, address) VALUES (1, 'Cidade do Dragao');
INSERT INTO football.court(id_court, address) VALUES (2, 'Cidade do Estadio');