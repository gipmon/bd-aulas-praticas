use p4g5;

--Jogadores

INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (12345678, 50000, 2);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (77777777, 10000, 3);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (12445678, 0, 4);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (39522123, 250, 6);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (40128390, 50, 9);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (52131283, 0, 10);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (43123123, 0, 11);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (12895726, 300, 15);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (46728109, 0, 17);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (90872134, 0, 18);

--Treinadores

INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (16728392, 40000, 13);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (49102019, 250, 14);

--Staff

INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (13124523, 100, 5);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (14563792, 1000, 7);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (29675821, 1250, 8);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (16758290, 30000, 1);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (19283847, 850, 12);
INSERT INTO football.internal_people (bi, salary, internal_id) VALUES (39821392, 1500, 16);




