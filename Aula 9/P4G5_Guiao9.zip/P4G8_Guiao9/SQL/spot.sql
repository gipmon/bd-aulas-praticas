use p4g5;

--Topo Norte

INSERT INTO football.spot(n_spot, row, id_section) VALUES (10, 'B', 1);
INSERT INTO football.spot(n_spot, row, id_section) VALUES (17, 'C', 1);

--Central

INSERT INTO football.spot(n_spot, row, id_section) VALUES (11, 'H', 2);
INSERT INTO football.spot(n_spot, row, id_section) VALUES (2, 'I', 2);