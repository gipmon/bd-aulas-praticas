use p4g5;

--Direc�ao

INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (16758290, 'Presidente', 1);
INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (13124523, 'Vice-Presidente', 1);

--Departamento Financeiro

INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (19283847, 'Director Financeiro', 2);
INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (14563792, 'Gestor Financeiro', 2);

--Departamento Comercial

INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (29675821, 'Director de Vendas', 3);
INSERT INTO futebol.staff_clube (bi, cargo, id_departamento) VALUES (39821392, 'Vendedor', 3);

