use p4g5;

--Sem Lugar Anual

INSERT INTO futebol.socios(bi, n_socio, quotas_em_dia, valor_das_quotas) VALUES (26718293, 2, 1, 20);
INSERT INTO futebol.socios (bi, n_socio, quotas_em_dia, valor_das_quotas) VALUES (28372192, 3, 0, 30);

--Com Lugar Anual

INSERT INTO futebol.socios (bi, n_socio, quotas_em_dia, valor_das_quotas) VALUES (15672829, 1, 1, 50);
