use p4g5;

--Seniores Masculinos

INSERT INTO futebol.tecnico(bi, id_federacao, funcao) VALUES (16728392, 132, 'Treinador');

--Seniores Femininos
INSERT INTO futebol.tecnico (bi, id_federacao, funcao) VALUES (49102019, 245, 'Treinador');