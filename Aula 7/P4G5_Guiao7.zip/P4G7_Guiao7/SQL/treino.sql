use p4g5;

INSERT INTO futebol.treino(data, hora, id_campo, nome_escalao) VALUES ('2015/05/21', '21:00', 1, 'Seniores Masculinos');
INSERT INTO futebol.treino(data, hora, id_campo, nome_escalao) VALUES ('2015/05/22', '19:00', 2, 'Seniores Femininos');