use p4g5;

--Seniores Femininos

INSERT INTO futebol.joga (bi, nome_escalao) VALUES (52131283, 'Seniores Femininos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (43123123, 'Seniores Femininos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (90872134, 'Seniores Femininos');

--Seniores Masculinos

INSERT INTO futebol.joga(bi, nome_escalao) VALUES (12345678, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (77777777, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (12445678, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (39522123, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (40128390, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (12895726, 'Seniores Masculinos');
INSERT INTO futebol.joga (bi, nome_escalao) VALUES (46728109, 'Seniores Masculinos');