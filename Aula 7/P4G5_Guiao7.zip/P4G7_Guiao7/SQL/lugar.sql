use p4g5;

--Topo Norte

INSERT INTO futebol.lugar(n_lugar, fila, id_seccao) VALUES (10, 'B', 1);
INSERT INTO futebol.lugar(n_lugar, fila, id_seccao) VALUES (17, 'C', 1);

--Central

INSERT INTO futebol.lugar(n_lugar, fila, id_seccao) VALUES (11, 'H', 2);
INSERT INTO futebol.lugar(n_lugar, fila, id_seccao) VALUES (2, 'I', 2);