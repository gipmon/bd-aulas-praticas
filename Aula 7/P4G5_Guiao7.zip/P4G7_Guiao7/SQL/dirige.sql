use p4g5;

--Seniores Masculinos

INSERT INTO futebol.dirige(bi, nome_escalao) VALUES (16728392, 'Seniores Masculinos');

--Seniores Femininos
INSERT INTO futebol.dirige (bi, nome_escalao) VALUES (49102019, 'Seniores Femininos');