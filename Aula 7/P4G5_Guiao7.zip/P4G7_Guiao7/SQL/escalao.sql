use p4g5;

INSERT INTO futebol.escalao(nome, idade_max) VALUES ('Seniores Masculinos', 50);
INSERT INTO futebol.escalao(nome, idade_max) VALUES ('Seniores Femininos', 50);
