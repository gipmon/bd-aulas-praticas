use p4g5;

--Seniores Femininos

INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (52131283, 1234, 59, 1.60);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (43123123, 09382, 58, 1.70);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (90872134, 23234, 52, 1.62);

--Seniores Masculinos

INSERT INTO futebol.jogador(bi, id_federacao, peso, altura) VALUES (12345678, 201, 77, 1.89);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (77777777, 30012, 75, 1.82);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (12445678, 2001, 70, 1.77);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (39522123, 3482, 72, 1.75);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (40128390, 1859, 69, 1.67);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (12895726, 2394, 80, 1.92);
INSERT INTO futebol.jogador (bi, id_federacao, peso, altura) VALUES (46728109, 19283, 82, 1.84);

