use p4g5;

INSERT INTO futebol.campo(id_campo, local) VALUES (1, 'Cidade do Dragao');
INSERT INTO futebol.campo(id_campo, local) VALUES (2, 'Cidade do Estadio');