use p4g5;

INSERT INTO futebol.departamento (id_departamento, endereco, nome) VALUES (1, 'Avenida do Dragao', 'Direccao');
INSERT INTO futebol.departamento (id_departamento, endereco, nome) VALUES (2, 'Rua do Estadio', 'Financeiro');
INSERT INTO futebol.departamento (id_departamento, endereco, nome) VALUES (3, 'Rua da Relva', 'Comercial');


