use p4g5;

INSERT INTO futebol.seccao(id_seccao, tipo) VALUES (1, 'Topo Norte');
INSERT INTO futebol.seccao(id_seccao, tipo) VALUES (2, 'Central');