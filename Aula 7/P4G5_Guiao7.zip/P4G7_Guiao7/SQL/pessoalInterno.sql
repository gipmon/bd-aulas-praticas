use p4g5;

--Jogadores

INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (12345678, 50000, 2);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (77777777, 10000, 3);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (12445678, 0, 4);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (39522123, 250, 6);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (40128390, 50, 9);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (52131283, 0, 10);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (43123123, 0, 11);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (12895726, 300, 15);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (46728109, 0, 17);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (90872134, 0, 18);

--Treinadores

INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (16728392, 40000, 13);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (49102019, 250, 14);

--Staff

INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (13124523, 100, 5);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (14563792, 1000, 7);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (29675821, 1250, 8);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (16758290, 30000, 1);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (19283847, 850, 12);
INSERT INTO futebol.pessoal_interno (bi, salario, id_interno) VALUES (39821392, 1500, 16);




