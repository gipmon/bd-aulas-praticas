use p4g5;

--Sem Lugar Anual

INSERT INTO football.members(bi, shares_in_day, shares_value) VALUES (26718293, 1, 20);
INSERT INTO football.members (bi, shares_in_day, shares_value) VALUES (28372192, 0, 30);

--Com Lugar Anual

INSERT INTO football.members (bi, shares_in_day, shares_value) VALUES (15672829, 1, 50);
