use p4g5;

INSERT INTO football.practice(date, hour, id_court, team_name) VALUES ('2015/05/21', '21:00', 1, 'Seniores Masculinos');
INSERT INTO football.practice(date, hour, id_court, team_name) VALUES ('2015/05/22', '19:00', 2, 'Seniores Femininos');