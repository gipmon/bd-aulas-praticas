use p4g5;

INSERT INTO football.department (department_id, address, name) VALUES (1, 'Avenida do Dragao', 'Direccao');
INSERT INTO football.department (department_id, address, name) VALUES (2, 'Rua do Estadio', 'Financeiro');
INSERT INTO football.department (department_id, address, name) VALUES (3, 'Rua da Relva', 'Comercial');


